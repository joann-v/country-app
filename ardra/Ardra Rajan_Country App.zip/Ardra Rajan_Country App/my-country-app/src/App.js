import React from 'react';
import './App.css';
import MainContextProvider from './context/main_context';
import AppRoutes from './routes/routes';

function App() {
  return (
    <div className="App">
      <MainContextProvider>
        <AppRoutes />
      </MainContextProvider>
    </div>
  );
}

export default App;
