import React, { useContext } from 'react';
import { Navigate, BrowserRouter, Routes, Route } from 'react-router-dom';
import LoginAndRegisterPage from '../components/login_register_page';
import Home from '../components/home';
import Profile from '../components/profile';
import Favuorites from '../components/favourites';
import { MainContext } from "../context/main_context";

function RequireAuth({ children }) {
  const { authed } = useContext(MainContext);

  return authed === true ? children : <Navigate to="/" replace />;
}

const AppRoutes = () => {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<LoginAndRegisterPage />}></Route>
        <Route path="/profile" element={<RequireAuth>
          <Profile />
        </RequireAuth>
        }></Route>
        <Route path="/home" element={<RequireAuth>
          <Home />
        </RequireAuth>
        }></Route>
        <Route path="/favourites" element={<RequireAuth>
          <Favuorites />
        </RequireAuth>
        }></Route>
      </Routes>
    </BrowserRouter>
  );
}

export default AppRoutes;