import React from 'react';

export const ApiServices = {
  fetchAPI () {
    return fetch('https://geoenrich.arcgis.com/arcgis/rest/services/World/geoenrichmentserver/Geoenrichment/countries?f=pjson')
      .then((response) => {
        const responseJson = response.json();
        return responseJson;
      });
  }
};
