import React from 'react';

export const LocalStorageService = {
    getFromLocalStorage(key) {
        return JSON.parse(localStorage.getItem(key));
    },
    setToLocalStorage(key, data) {
        return localStorage.setItem(key, JSON.stringify(data));
    },
    deleteFromLocalStorage(key) {  
        return localStorage.removeItem(key);
    },
    clearFromLocalStorage() {
        return localStorage.clear();
    }
};

