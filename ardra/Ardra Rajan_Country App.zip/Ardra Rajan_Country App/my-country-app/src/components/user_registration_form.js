import React, { useEffect, useState } from "react";
import '../css/UserRegistration.css';
import { LocalStorageService } from '../services/localstorage_services';
import { ApiServices } from '../services/api_services';
import { toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

const UserRegistration = (props) => {

    const { setIsLogin } = props
    const [userdata, setUserdata] = useState({});
    const [countries, setCountries] = useState([]);
    const [error, setError] = useState({});
    const [formisvalid, setFormisvalid] = useState(false);

    const registerSuccessNotify = () => toast("Registration successfull.", {
        position: toast.POSITION.TOP_CENTER,
        autoClose: 2000
    });

    const validation = userdata => {
        const specialChars = /[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]+/;
        const errors = {};
        if (userdata.username === "") { errors.username = "Please enter your name"; }
        else if (typeof (userdata.username) !== "undefined") {
            if (specialChars.test(userdata.username)) {
                errors.username = "Enter a valid name";
            }
        }
        if (userdata.useremail === "") { errors.useremail = "Please enter your emailid."; }
        else if (typeof (userdata.useremail) !== "undefined") {
            const validationChars = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
            if (!validationChars.test(userdata.useremail)) {
                errors.useremail = "This is not a valid email format!";
            }
        }
        if (userdata.userpassword === "") { errors.userpassword = "Please enter password"; }
        else if (typeof (userdata.userpassword) !== "undefined") {
            if (userdata.userpassword.length > 15 || (specialChars.test(userdata.userpassword))) {
                errors.userpassword = "Password must be less than 15 characters and should not contain any special characters";
            }
        }
        if (userdata.userConfirmPassword === "") { errors.userConfirmPassword = "Password Confirmation is required"; }
        else if (typeof (userdata.userConfirmPassword) !== "undefined") {
            if (userdata.userConfirmPassword.length > 15 || (specialChars.test(userdata.userConfirmPassword))) {
                errors.userConfirmPassword = "Password must be less than 15 characters and should not contain any special characters";
            }
        }
        return errors;
    }

    const inputChangeHandler = (event) => {
        const value = event.target.value;
        setUserdata({ ...userdata, [event.target.name]: value });
        setError(validation(userdata));
        if (Object.keys(error).length === 0) {
            setFormisvalid(true);
        } else {
            setFormisvalid(false);
        }
    };

    useEffect(() => {
        ApiServices.fetchAPI().then((resp) => {
            setCountries(resp.countries);
        })
    }, []);

    const submitvalidation = (userdata) => {
        const err = {};
        if (!userdata.username) {
            err.username = "Please enter your name";
        }
        if (!userdata.useremail) {
            err.useremail = "Please enter your emailid";
        }
        if (!userdata.userpassword) {
            err.userpassword = "Please enter password";
        }
        if (!userdata.userConfirmPassword) {
            err.userConfirmPassword = "Password Confirmation is required";
        }
        if (!userdata.usercountry) {
            err.usercountry = "Please select a country";
        }
        if (userdata.userConfirmPassword && userdata.userpassword) {
            if (userdata.userConfirmPassword !== userdata.userpassword) {
                err.userConfirmPassword = "Confirm password must be same as the password";
            }
        }
        setError(err);
        return (Object.keys(err).length);
    }

    const submitHandler = event => {
        event.preventDefault();
        const errLength = submitvalidation(userdata);
        if (+errLength === 0) {
            setFormisvalid(true);
            LocalStorageService.setToLocalStorage(userdata.useremail, userdata);
            if (userdata.username && userdata.useremail && userdata.userpassword && userdata.userConfirmPassword && userdata.usercountry) {
                setUserdata({});
                registerSuccessNotify();
            }
        } else {
            setFormisvalid(false);
        }
    }

    const loginHandler = (event) => {
        setIsLogin(true)
    }

    return (
        <div className="container">
            <div className="regheader">Register</div>
            <div className="regcontent">
                <div className="form">
                    <div className="form-group">
                        <label htmlFor="username">Name</label>
                        <input className="regInput" type="text" id="user-name" name="username" placeholder="name" value={userdata.username} onChange={inputChangeHandler} onBlur={inputChangeHandler} />
                    </div>
                    {!formisvalid && <span className="errorr">{error.username}</span>}
                    <div className="form-group">
                        <label htmlFor="useremail" >Email</label>
                        <input className="regInput" type="email" id="user-email" name="useremail" placeholder="email" value={userdata.useremail} onChange={inputChangeHandler} onBlur={inputChangeHandler} />
                    </div>
                    {!formisvalid && <span className="errorr">{error.useremail}</span>}
                    <div className="form-group">
                        <label htmlFor="userpassword" >Password</label>
                        <input className="regInput" type="password" id="user-password" name="userpassword" placeholder="password" value={userdata.userpassword} onChange={inputChangeHandler} />
                    </div>
                    {!formisvalid && <span className="errorr">{error.userpassword}</span>}
                    <div className="form-group">
                        <label htmlFor="userConfirmPassword" >Confirm Password</label>
                        <input className="regInput" type="password" id="user-Confirmpassword" name="userConfirmPassword" placeholder="password" value={userdata.userConfirmPassword} onChange={inputChangeHandler} onBlur={inputChangeHandler} />
                    </div>
                    {!formisvalid && <span className="errorr">{error.userConfirmPassword}</span>}
                    <div className="form-group">
                        <label htmlFor="usercountry" >Country</label>
                        <select type="text" name="usercountry" placeholder="country" onChange={inputChangeHandler} onBlur={inputChangeHandler}>
                            <option >Select</option>
                            {countries.map((country, index) => {
                                return <option key={index}>{country.name}</option>
                            })
                            }
                        </select>
                        {!formisvalid && <span className="errorr">{error.usercountry}</span>}
                    </div>
                </div>
            </div>
            <div className="footer">
                <button type="button" className="registerbtn" onClick={submitHandler}>
                    Register
                </button>
            </div>
            <div>
                <h1>Aldready have an account? <button className="loginbtn" onClick={loginHandler}>Login</button></h1>
            </div>
        </div>
    )
}

export default UserRegistration;