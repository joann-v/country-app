import React, { useContext, useState } from "react";
import '../css/Login.css';
import { useNavigate } from 'react-router-dom';
import { MainContext } from "../context/main_context";
import { LocalStorageService } from '../services/localstorage_services';

const Login = (props) => {

    const { setIsLogin } = props
    const { setLogindatafromlocalstore, valueisvalid, setValueisvalid, setAuthed } = useContext(MainContext);
    const navigate = useNavigate();
    const [logindata, setLogindata] = useState({});
    const [error, setError] = useState('');

    const inputChangeHandler = (event) => {
        const value = event.target.value;
        setLogindata({ ...logindata, [event.target.name]: value });
    };

    const submitHandler = () => {
        if (logindata && logindata.useremail) {
            const datadatastorage = LocalStorageService.getFromLocalStorage(logindata.useremail);
            if (datadatastorage && datadatastorage.useremail && logindata && logindata.useremail) {
                if (datadatastorage.useremail === logindata.useremail && datadatastorage.userpassword === logindata.userpassword) {
                    setValueisvalid(true);
                    setLogindatafromlocalstore(datadatastorage);
                    setAuthed(true);
                    LocalStorageService.setToLocalStorage('currentLogin', logindata.useremail);
                }
                else {
                    setError('Please enter a valid password.');
                }
            } else {
                setError('Please enter a valid email.');
            }
        } else {
            setError('Please enter all the fields');
        }

    };

    const registerHandler = () => {
        setIsLogin(false);
    }

    return (
        <div className="container">
            <div className="header">Login</div>
            {valueisvalid && navigate('/home')}
            {!valueisvalid && <span className="error">{error}</span>}
            <div className="content">
                <div className="form">
                    <div className="form-group">
                        <label htmlFor="useremail">Email</label>
                        <input type="text" name="useremail" placeholder="email" onChange={inputChangeHandler} />
                    </div>
                    <div className="form-group">
                        <label htmlFor="userpassword">Password</label>
                        <input type="password" name="userpassword" placeholder="password" onChange={inputChangeHandler} />
                    </div>
                </div>
            </div>
            <div className="footer">
                <button type="button" className="btn" onClick={() => submitHandler()}>
                    Login
                </button>
            </div>
            <div>
                <h1>Don't have an account? <button className="regbtn" onClick={() => registerHandler()}>Register</button></h1>
            </div>
        </div>
    )
}

export default Login;


