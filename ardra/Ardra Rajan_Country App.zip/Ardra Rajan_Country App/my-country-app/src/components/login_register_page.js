import React, { useState } from 'react';
import '../css/login_register.css'
import Login from './login_form';
import UserRegistration from './user_registration_form';

const LoginAndRegisterPage = () => {
    const [isLogin, setIsLogin] = useState(true);

    return (
            <div className="login">
                <div className="container" >
                    {isLogin && (<Login setIsLogin={setIsLogin}/>)}
                    {!isLogin && (<UserRegistration setIsLogin={setIsLogin}/>)}
                </div>
            </div>
    );
}

export default LoginAndRegisterPage;