import React from 'react';

const Pagination = (props) => {
    const { postsPerPage, totalNoOfCountries, totalNoOfDefaultCountries, paginate, showdefaultCountries } = props
    const pageNumbers = [];

    console.log(showdefaultCountries);
    if (showdefaultCountries) {
        for (let i = 1; i <= Math.ceil(totalNoOfDefaultCountries / postsPerPage); i++) {
            pageNumbers.push(i);
        }
    } else {
        for (let i = 1; i <= Math.ceil(totalNoOfCountries / postsPerPage); i++) {
            pageNumbers.push(i);
        }
    }

    return (
        <nav aria-label="...">
            <ul className="pagination pagination-lg justify-content-center">

                {pageNumbers.map(number => (
                    <li key={number} className='page-item'>
                        <a className='page-link' href="#" onClick={() => { paginate(number) }} >
                            {number}
                        </a>
                    </li>
                ))}

            </ul>
        </nav>
    )
}
export default Pagination;