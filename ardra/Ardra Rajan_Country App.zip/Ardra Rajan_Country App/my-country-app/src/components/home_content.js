import React, { useState, useContext, useEffect } from 'react';
import { MainContext } from '../context/main_context';
import { HomeContext } from '../context/home_context';
import Pagination from './pagination';
import { LocalStorageService } from '../services/localstorage_services';
import '../css/home_content.css';
import CountryDetails from './country_details';
import { ApiServices } from '../services/api_services';

const HomeCotent = () => {
    const { currentPage, setCurrentPage, countriesofcontinent, favuoritesList,
        setFavuoritesList, selectedContinent, setSelectedContinent } = useContext(MainContext);
    const {showdefaultCountries,showdefault } = useContext(HomeContext);
    const [mainFavList, setMainFavList] = useState([]);
    const [show, setShow] = useState(false);
    const [detailsOfaCountry, setDetailsOfaCountry] = useState([]);
    const [defaultCountries, setDefaultCountries] = useState([]);
    const postsperpage = 5;

    const indexOfLastPost = currentPage * postsperpage;
    const indexOfFirstPost = indexOfLastPost - postsperpage;
    const currentDefaultPosts = defaultCountries.slice(indexOfFirstPost, indexOfLastPost);
    const currentPosts = countriesofcontinent.slice(indexOfFirstPost, indexOfLastPost);

    const paginate = (pageNumber) => {
        setCurrentPage(pageNumber);
    };

    useEffect(() => {
        setFavuoritesList(LocalStorageService.getFromLocalStorage('favourites') ? LocalStorageService.getFromLocalStorage('favourites') : []);
        const val = LocalStorageService.getFromLocalStorage('currentLogin');
        const value = LocalStorageService.getFromLocalStorage('favourites');
        if (value) {
            const favorite = value.filter(v => v.email === val);
            if (favorite.length > 0) {
                setMainFavList(favorite[0].favourites);
            }
        }
    }, [])

    useEffect(() => {
        setDefaultCountries([]);
        setSelectedContinent('Africa')
        ApiServices.fetchAPI().then((resp) => {
            const arr = resp.countries;
            return arr.map((a) => {
                if (a.continent === 'Africa') {
                    setDefaultCountries(previousState => [...previousState, {
                        "id": a.id,
                        "name": a.name,
                        "distanceUnits": a.distanceUnits,
                        "currencyName": a.currencyName,
                        "esriUnits": a.esriUnits,
                        "currencyCode": a.currencyCode,
                        "abbr3": a.abbr3
                    }]);
                };
            });
        })
        showdefault(true);
    }, [])

    let value = [];
    const objectsetting = (country, id) => {
        value.push(country)
        let localstorageFavourites = [...favuoritesList];
        const val = LocalStorageService.getFromLocalStorage('currentLogin');
        const index = localstorageFavourites.findIndex(x => x.email === val);
        if (index > -1) {
            const countryIndex = localstorageFavourites[index].favourites.findIndex(x => x === country)
            if (countryIndex > -1) {
                localstorageFavourites[index].favourites.splice(countryIndex, 1);
                setMainFavList(localstorageFavourites[index].favourites);
            } else {
                localstorageFavourites[index].favourites.push(country);
                setMainFavList(localstorageFavourites[index].favourites);
            }
        } else {
            localstorageFavourites.push({ email: LocalStorageService.getFromLocalStorage('currentLogin'), favourites: [country] });
            if (localstorageFavourites[index]) {

                setMainFavList(localstorageFavourites[index].favourites);
            }
        }
        setFavuoritesList(localstorageFavourites);
        LocalStorageService.setToLocalStorage('favourites', localstorageFavourites);
    };

    const closemodal = () => {
        setShow(false);
    };

    const detailHandler = (name, id, distanceUnits, currencyName, currencyCode, esriUnits, abbr3) => {
        setDetailsOfaCountry([name, id, distanceUnits, currencyName, currencyCode, esriUnits, abbr3])
        setShow(true);
    };

    return (

        <div className="table-wrapper">
            <div className="row">
                <div className="col-12">
                    <div className="row">
                        <h1 className='countryNamesHeading'>{selectedContinent}</h1>
                    </div>
                </div>
                <div className="row">
                    <div className="col-12 tableCls">
                        <table className="table table-bordered ">
                            <thead>
                                <tr>
                                    <th scope="col">Countries</th>
                                    <th scope="col">Add to Favourites</th>
                                    <th scope="col">Details</th>
                                </tr>
                            </thead>
                            <tbody>
                                {showdefaultCountries && currentDefaultPosts.map((country, index) => {
                                    return <tr key={index} >
                                        <td>
                                            {country.name}
                                        </td>
                                        <td>
                                            <button className="fav" onClick={() => {
                                                objectsetting(country.name);
                                            }
                                            }> <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill={mainFavList.includes(`${country.name}`) ? "red" : "currentColor"} className="bi bi-heart" viewBox="0 0 16 16">
                                                    <path d="m8 2.748-.717-.737C5.6.281 2.514.878 1.4 3.053c-.523 1.023-.641 2.5.314 4.385.92 1.815 2.834 3.989 6.286 6.357 3.452-2.368 5.365-4.542 6.286-6.357.955-1.886.838-3.362.314-4.385C13.486.878 10.4.28 8.717 2.01L8 2.748zM8 15C-7.333 4.868 3.279-3.04 7.824 1.143c.06.055.119.112.176.171a3.12 3.12 0 0 1 .176-.17C12.72-3.042 23.333 4.867 8 15z" />
                                                </svg></button>
                                        </td>
                                        <td>
                                            <button className='detailbtn' onClick={() => { detailHandler(country.name, country.id, country.distanceUnits, country.currencyName, country.currencyCode, country.esriUnits, country.abbr3); }}><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" className="bi bi-info-circle" viewBox="0 0 16 16">
                                                <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z" />
                                                <path d="m8.93 6.588-2.29.287-.082.38.45.083c.294.07.352.176.288.469l-.738 3.468c-.194.897.105 1.319.808 1.319.545 0 1.178-.252 1.465-.598l.088-.416c-.2.176-.492.246-.686.246-.275 0-.375-.193-.304-.533L8.93 6.588zM9 4.5a1 1 0 1 1-2 0 1 1 0 0 1 2 0z" />
                                            </svg></button>
                                        </td>
                                    </tr>
                                })
                                }
                                {show && <CountryDetails countryDetails={detailsOfaCountry} closeModal={setShow} />}
                                {!showdefaultCountries && currentPosts.map((country, index) => {
                                    return <tr key={index} >
                                        <td>
                                            {country.name}
                                        </td>
                                        <td>
                                            <button className="fav" onClick={() => {
                                                objectsetting(country.name, country.id);
                                            }
                                            }><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill={mainFavList.includes(`${country.name}`) ? "red" : "currentColor"} className="bi bi-heart" viewBox="0 0 16 16">
                                                    <path d="m8 2.748-.717-.737C5.6.281 2.514.878 1.4 3.053c-.523 1.023-.641 2.5.314 4.385.92 1.815 2.834 3.989 6.286 6.357 3.452-2.368 5.365-4.542 6.286-6.357.955-1.886.838-3.362.314-4.385C13.486.878 10.4.28 8.717 2.01L8 2.748zM8 15C-7.333 4.868 3.279-3.04 7.824 1.143c.06.055.119.112.176.171a3.12 3.12 0 0 1 .176-.17C12.72-3.042 23.333 4.867 8 15z" />
                                                </svg></button>
                                        </td>
                                        <td>
                                            <button className='detailbtn' onClick={() => { detailHandler(country.name, country.id, country.distanceUnits, country.currencyName, country.currencyCode, country.esriUnits, country.abbr3); }}><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" className="bi bi-info-circle" viewBox="0 0 16 16">
                                                <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z" />
                                                <path d="m8.93 6.588-2.29.287-.082.38.45.083c.294.07.352.176.288.469l-.738 3.468c-.194.897.105 1.319.808 1.319.545 0 1.178-.252 1.465-.598l.088-.416c-.2.176-.492.246-.686.246-.275 0-.375-.193-.304-.533L8.93 6.588zM9 4.5a1 1 0 1 1-2 0 1 1 0 0 1 2 0z" />
                                            </svg></button>
                                        </td>
                                    </tr>
                                })
                                }
                            </tbody>
                        </table>
                    </div>
                </div>
                <div className="col-12">
                    <Pagination
                        showdefaultCountries={showdefaultCountries}
                        postsPerPage={postsperpage}
                        totalNoOfCountries={countriesofcontinent.length}
                        totalNoOfDefaultCountries={defaultCountries.length}
                        paginate={paginate}
                    />
                </div>
            </div>
        </div >
    )
}

export default HomeCotent;
