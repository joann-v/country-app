import React, { useContext, useState } from 'react';
import { MainContext } from '../context/main_context';
import { HomeContext } from '../context/home_context';
import { ApiServices } from '../services/api_services';
import '../css/home_sidebar.css';

const HomeSidebar = () => {

    const { setCountriesofcontinent, setCurrentPage, setSelectedContinent } = useContext(MainContext);
    const {showdefault } = useContext(HomeContext);
    const [countriesareselected, setCountriesareselected] = useState(false);
    const continents =['Africa', 'Asia', 'Europe', 'North America', 'Oceania', 'South America'];

    const selectCountries = (event) => {
        setCurrentPage(1);
        showdefault(false);
        setCountriesofcontinent([]);
        const contin = event.target.value;
        setSelectedContinent(contin);
        ApiServices.fetchAPI().then((resp) => {
            const arr = resp.countries;
            return arr.map((a) => {
                if (a.continent === contin) {
                    setCountriesofcontinent(previousState => [...previousState, {
                        "id": a.id,
                        "name": a.name,
                        "distanceUnits": a.distanceUnits,
                        "currencyName": a.currencyName,
                        "esriUnits": a.esriUnits,
                        "currencyCode": a.currencyCode,
                        "abbr3": a.abbr3
                    }]);
                };
            });
        })
        setCountriesareselected(true)
    };

    // useEffect(() => {
    //     setDefaultCountries([]);
    //     setSelectedContinent('Africa')
    //     ApiServices.fetchAPI().then((resp) => {
    //         const arr = resp.countries;
    //         return arr.map((a) => {
    //             if (a.continent === 'Africa') {
    //                 setDefaultCountries(previousState => [...previousState, {
    //                     "id": a.id,
    //                     "name": a.name,
    //                     "distanceUnits": a.distanceUnits,
    //                     "currencyName": a.currencyName,
    //                     "esriUnits": a.esriUnits,
    //                     "currencyCode": a.currencyCode,
    //                     "abbr3": a.abbr3
    //                 }]);
    //             };
    //         });
    //     })
    //     setShowdefaultCountries(true);
    // }, [])

    return (
        <div className='sidebar'>
            <div className="sidebar__item">
                <h1 className="navbar-item">Continents</h1>
                <ul className="navbar-nav">
                    {continents.map((continent, index) => {
                        return <li key={index}><button className='continentbtn' value={continent} onClick={selectCountries}>{continent}</button></li>
                    })
                    }
                </ul>
            </div>
        </div>

    )
}

export default HomeSidebar;
