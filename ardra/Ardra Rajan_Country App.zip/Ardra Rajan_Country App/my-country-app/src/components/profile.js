import React, { useState, useContext } from 'react';
import { MainContext } from '../context/main_context';
import { useNavigate } from 'react-router-dom';
import { LocalStorageService } from '../services/localstorage_services';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import '../css/Profile.css';

const Profile = () => {

  const { logindatafromlocalstore, setLogindatafromlocalstore, setAuthed, setValueisvalid } = useContext(MainContext);
  const navigate = useNavigate();

  const [oldvalue, setOldvalue] = useState('');
  const [isEditable, setIsEditable] = useState(false);
  const [editPassword, setEditPassword] = useState(false);

  const nameUpdateSuccessMsg = () => toast("Name updated successfully.", {
    position: toast.POSITION.TOP_CENTER,
    autoClose: 2000
  });

  const passwordUpdateSuccessMsg = () => toast("Password updated successfull.", {
    position: toast.POSITION.TOP_CENTER,
    autoClose: 2000
  });

  const editProfile = () => {
    setIsEditable(true);
    setOldvalue(logindatafromlocalstore.username);
  };

  const inputChangeHandler = (event) => {
    const val = event.target.value;
    if (event.target.name === 'userpassword') {
      setLogindatafromlocalstore({ ...logindatafromlocalstore, [event.target.name]: val, 'userConfirmPassword': val });
    } else {
      setLogindatafromlocalstore({ ...logindatafromlocalstore, [event.target.name]: val });
    }
  };

  const passwordsavehandler = (event) => {
    event.preventDefault();
    LocalStorageService.deleteFromLocalStorage(oldvalue);
    LocalStorageService.setToLocalStorage(logindatafromlocalstore.useremail, logindatafromlocalstore);
    setEditPassword(false);
    setIsEditable(false);
    passwordUpdateSuccessMsg();
  };

  const namesavehandler = (event) => {
    event.preventDefault();
    LocalStorageService.deleteFromLocalStorage(oldvalue);
    LocalStorageService.setToLocalStorage(logindatafromlocalstore.useremail, logindatafromlocalstore);
    setEditPassword(false);
    setIsEditable(false);
    nameUpdateSuccessMsg();
  };

  const deleteaccount = (event) => {
    event.preventDefault();
    LocalStorageService.deleteFromLocalStorage(logindatafromlocalstore.useremail);
    setValueisvalid(false);
    setAuthed(false);
    navigate('/');
  };

  const logout = (event) => {
    event.preventDefault();
    setLogindatafromlocalstore({});
    setValueisvalid(false);
    setAuthed(false);
    navigate('/');
  };

  const gotohomepage = (event) => {
    event.preventDefault();
    navigate('/home');
  };
  const changePassword = (event) => {
    event.preventDefault();
    setEditPassword(true);
    setOldvalue(logindatafromlocalstore.username);
  };

  return (
    <div >
      <nav className="navbar-a">
        <div className="container-fluid-a">
          <button className="navbar-toggler-comp">
            <span className="navbar-toggler-icon-a" onClick={gotohomepage}>HOME</span>
          </button>
          <button className="navbar-toggler-comp">
            <span className="navbar-toggler-icon-a" onClick={editProfile}>EDIT</span>
          </button>
          <button className="navbar-toggler-comp">
            <span className="navbar-toggler-icon-a" onClick={changePassword}>CHANGE PASSWORD</span>
          </button>
          <button className="navbar-toggler-comp">
            <span className="navbar-toggler-icon-a" onClick={logout}>LOGOUT</span>
          </button>
          <button className="navbar-toggler-comp">
            <span className="navbar-toggler-icon-a" onClick={deleteaccount}>DELETE ACCOUNT</span>
          </button>
        </div>
      </nav>
      <div className='carda'>
        {!editPassword ? <h1></h1> : <div>
          <label htmlFor="userpassword" className="form-label"><span className='labels'>Password</span></label>
          <input type="password" id="user-password" name="userpassword" value={logindatafromlocalstore.userpassword} onChange={inputChangeHandler} />
        </div>
        }
        {editPassword && <button className='savebtn' onClick={passwordsavehandler}>SAVE</button>}
        {!isEditable ? <h2 className='profileDetail'><span className='labels'>Name :</span> {logindatafromlocalstore.username}</h2> : <div>
          <label htmlFor="username" className="form-label"><span className='labels'>Name</span></label>
          <input type="text" id="user-name" name="username" value={logindatafromlocalstore.username} onChange={inputChangeHandler} />
        </div>}
        {isEditable && <button className='savebtn' onClick={namesavehandler}>SAVE</button>}

        <h2 className='profileDetail'><span className='labels'>Email address :</span> {logindatafromlocalstore.useremail}</h2>
        <h2 className='profileDetail'><span className='labels'>Country :</span> {logindatafromlocalstore.usercountry}</h2>
      </div>
      <ToastContainer />
    </div>
  );
}

export default Profile;