import React, { useState, useContext, useEffect } from 'react';
import { MainContext } from '../context/main_context';
import Pagination from './pagination';
import '../css/favourites.css';
import { useNavigate } from 'react-router-dom';
import { LocalStorageService } from '../services/localstorage_services';

const Favuorites = () => {

    const navigate = useNavigate();
    const { setLogindatafromlocalstore, favuoritesList, setFavuoritesList, setValueisvalid,
        setAuthed, currentPage, setCurrentPage } = useContext(MainContext);
    const [currentfavouritesList, setcurrentfavouritesList] = useState([]);
    const [listLength, setListLength] = useState([]);
    const [list, setList] = useState([]);
    const [favListPresent, setFavListPresent] = useState(false);

    useEffect(() => {
        setCurrentPage(1);
        const val = LocalStorageService.getFromLocalStorage('currentLogin');
        const value = LocalStorageService.getFromLocalStorage('favourites');
        if(value){
            const favorite = value.filter(v => v.email === val);
            if (favorite.length > 0) {
                setcurrentfavouritesList(() => favorite[0]);
                setList(() => favorite[0].favourites);
                setFavListPresent(true);
                setListLength(favorite[0].favourites.length);
            } else {
                setFavListPresent(false);
            }
        }
    }, [])

    const indexOfLastPost = currentPage * 5;
    const indexOfFirstPost = indexOfLastPost - 5;
    const currentPosts = list.slice(indexOfFirstPost, indexOfLastPost);

    const deleteFromFavourites = (id) => {
        let localstorageFavourites = [...favuoritesList];
        const val = LocalStorageService.getFromLocalStorage('currentLogin');
        const index = localstorageFavourites.findIndex(x => x.email === val);
        if (index > -1) {
            const countryIndex = localstorageFavourites[index].favourites.findIndex(x => x === id)
            if (countryIndex > -1) {
                localstorageFavourites[index].favourites.splice(countryIndex, 1);
            }
            setcurrentfavouritesList(localstorageFavourites[index]);
        }
        setFavuoritesList(localstorageFavourites);
        LocalStorageService.setToLocalStorage('favourites', localstorageFavourites);
        setList(currentfavouritesList.favourites);
        setListLength(list.length);

    }

    const goToProfile = () => {
        navigate("/profile");
    }

    const logout = (event) => {
        event.preventDefault();
        setLogindatafromlocalstore({});
        setValueisvalid(false);
        setAuthed(false);
        navigate('/');
    };

    const home = () => {
        navigate("/home");
    }

    const paginate = (pageNumber) => {
        setCurrentPage(pageNumber);
    };


    return (
        <div className="container-fluid-b">
            <nav >
                <div className="navbar">
                    <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <span className="navbar-toggler-icon" onClick={goToProfile}>Profile</span>
                    </button>
                    <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <span className="navbar-toggler-icon" onClick={home}>Home</span>
                    </button>
                    <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <span className="navbar-toggler-icon" onClick={logout}>Logout</span>
                    </button>
                </div>
            </nav>
            <div className="row">
                <div className="col-12">
                    <h1 className='favHeading'>Favourites</h1>
                </div>
            </div>
            <div className="row">
                <div className="col-12">
                    <div className="card">
                        <div className="card__body">
                            <ul className="list-group list-group-numbered">
                                <table className="table">
                                    {(!favListPresent || list.length === 0) && <h1>You do not have any favourites!</h1>}
                                    <thead>
                                        <tr>
                                            <th scope="col">Countries</th>
                                            <th scope="col">Remove from favourites</th>
                                        </tr>
                                    </thead>
                                    {currentfavouritesList && currentfavouritesList.favourites && currentPosts.map((country,index) => (
                                        <tbody key={index}>
                                            <tr>
                                                <td>
                                                    {country}
                                                </td>
                                                <td>
                                                    <button className="deleteBtn" onClick={() => {
                                                        deleteFromFavourites(country);
                                                    }
                                                    }><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" className="bi bi-trash" viewBox="0 0 16 16">
                                                            <path d="M5.5 5.5A.5.5 0 0 1 6 6v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm2.5 0a.5.5 0 0 1 .5.5v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm3 .5a.5.5 0 0 0-1 0v6a.5.5 0 0 0 1 0V6z" />
                                                            <path fillRule="evenodd" d="M14.5 3a1 1 0 0 1-1 1H13v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V4h-.5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1H6a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1h3.5a1 1 0 0 1 1 1v1zM4.118 4 4 4.059V13a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V4.059L11.882 4H4.118zM2.5 3V2h11v1h-11z" />
                                                        </svg></button>
                                                </td>
                                            </tr>

                                        </tbody>
                                    ))}
                                </table>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div className="col-12">
                <Pagination
                    postsPerPage={5}
                    totalNoOfCountries={listLength}
                    paginate={paginate}
                />
            </div>
        </div>
    );
}
export default Favuorites;