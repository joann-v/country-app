import React, { useState } from "react";
import '../css/country_details.css';

function CountryDetails(props) {
    const { countryDetails } = props
   
    return (
        <div className="modal">
            <div className="modal-container">
                <div className="modal-header">
                    <h5 className="modal-title">{countryDetails[0]}</h5>
                    <button onClick={() => props.closeModal(false)} type="button" id="closebtn" >X</button>
                </div>
                <div className="modal-body">
                    <h1 className="modalList"><span className="modalLabel">Id               : </span>{countryDetails[1]}</h1>
                    <h1 className="modalList"><span className="modalLabel">Distance in units: </span>{countryDetails[2]}</h1>
                    <h1 className="modalList"><span className="modalLabel">Currency name    : </span>{countryDetails[3]}</h1>
                    <h1 className="modalList"><span className="modalLabel">Currency code    : </span>{countryDetails[4]}</h1>
                    <h1 className="modalList"><span className="modalLabel">ESRI units       : </span>{countryDetails[5]}</h1>
                    <h1 className="modalList"><span className="modalLabel">abbr3            : </span>{countryDetails[6]}</h1>
                </div>
            </div>
        </div>
    )
}
export default CountryDetails;