import React from 'react';
import '../css/Home.css';
import HomeCotent from './home_content';
import HomeSidebar from './home_sidebar';
import HomeTopNavbar from './home_topnavbar';
import HomeContextProvider from '../context/home_context';

const Home = () => {

  return (
    <HomeContextProvider>
      <div className="wrapper">
        <HomeTopNavbar />
        <div className='row'>
          <div className="col-md-5">
            <HomeSidebar />
          </div>
          <div className="col-md-7">
            <HomeCotent />
          </div>
        </div>
      </div>
    </HomeContextProvider>
  );
}

export default Home;