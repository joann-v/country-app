import React, { useContext } from 'react';
import { MainContext } from '../context/main_context';
import '../css/home_topnavbar.css';
import { useNavigate } from 'react-router-dom';


const HomeTopNavbar = () => {
    const { setLogindatafromlocalstore, setValueisvalid, setAuthed, authed } = useContext(MainContext);
    const navigate = useNavigate();

    const goToProfile = () => {
        navigate("/profile");
    }
    const logout = (event) => {
        event.preventDefault();
        setLogindatafromlocalstore({});
        setValueisvalid(false);
        setAuthed(false);
        navigate('/');
    };
    const Favourites = () => {
        navigate("/favourites");
    }

    return (
        <nav >
            <div className="container-fluid">
                <a className="navbar-brand" >Country App</a>
                <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span className="navbar-toggler-icon" onClick={goToProfile}>Profile</span>
                </button>
                <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span className="navbar-toggler-icon" onClick={Favourites}>Favourites</span>
                </button>
                <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    {authed && <span className="navbar-toggler-icon" onClick={logout}>Logout</span>}
                </button>

            </div>
        </nav>

    )
}


export default HomeTopNavbar;
