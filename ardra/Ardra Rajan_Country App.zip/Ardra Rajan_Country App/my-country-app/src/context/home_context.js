import React, { useState, createContext } from "react";

export const HomeContext = createContext({});
const HomeContextProvider = (props) => {
    
    const [showdefaultCountries, setShowdefaultCountries] = useState(false);
    const showdefault = (val)=>{
        setShowdefaultCountries(val);
    }
    
    return (
        <HomeContext.Provider value={{ showdefaultCountries,showdefault}}>
            {props.children}
        </HomeContext.Provider>
    );
}

export default HomeContextProvider;
