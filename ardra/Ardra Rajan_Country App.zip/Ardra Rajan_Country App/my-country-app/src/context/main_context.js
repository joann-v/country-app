import React, { useState, createContext } from "react";

export const MainContext = createContext({});
const MainContextProvider = (props) => {
    const [valueisvalid, setValueisvalid] = useState(false);
    const [logindatafromlocalstore, setLogindatafromlocalstore] = useState({});
    const [countriesofcontinent, setCountriesofcontinent] = useState([]);
    const [selectedContinent, setSelectedContinent] = useState('Africa');
    const [favuoritesList, setFavuoritesList] = useState([]);
    const [currentPage, setCurrentPage] = useState(1);
    const [authed, setAuthed] = useState(false);

    return (
        <MainContext.Provider value={{ authed, setAuthed, valueisvalid, 
        setValueisvalid, logindatafromlocalstore, setLogindatafromlocalstore,  countriesofcontinent, setCountriesofcontinent, 
        favuoritesList, setFavuoritesList, currentPage, setCurrentPage, selectedContinent, 
        setSelectedContinent }}>
            {props.children}
        </MainContext.Provider>
    );
}

export default MainContextProvider;
