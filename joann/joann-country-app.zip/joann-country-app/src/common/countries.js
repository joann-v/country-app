import { fetchapi } from "../services/fetchapi.service";

export default async function countries() {
  return fetchapi();
}
