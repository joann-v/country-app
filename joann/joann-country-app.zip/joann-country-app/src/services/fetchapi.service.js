export async function fetchapi() {
  console.log("fetchhhh!");
  const baseURL =
    "https://geoenrich.arcgis.com/arcgis/rest/services/World/geoenrichmentserver/Geoenrichment/countries?f=pjson";

  try {
    let res = await fetch(baseURL);
    return await res.json();
  } catch (error) {
    console.log(error);
  }
}
