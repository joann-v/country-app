import { createContext } from 'react'

const CountryContext = createContext()

export default CountryContext