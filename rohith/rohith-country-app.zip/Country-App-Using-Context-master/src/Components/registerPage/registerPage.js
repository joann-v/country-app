import React from 'react';
import RegisterPageForm from './registerPageForm/registerPageForm';
function RegisterPage() {
    return (
        <div>
            <RegisterPageForm />
        </div>
    )
}

export default RegisterPage
